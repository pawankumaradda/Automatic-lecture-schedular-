    /*
    * To change this template, choose Tools | Templates
    * and open the template in the editor.
    */
    package practime;

    import java.sql.*;
    import java.util.*;

    /**
    *
    * @author Pawan Kumar
    */
    public class schedule1 {

    
    mainpage m2;    
    int checksum[][]=new int[7][7]; 
    //   float g[]=new float[7]; 
    //   int g1[]=new int[7]; 
    int i = 0, j = 0, k, l, flag = 5, max, key = 0, sum,u,z,y,indo1;
    int count=0;
    int rand,rand1;
    //   int time[][]=new int[7][7];;
    String dat[][] = new String[7][7];
    String b[][] = new String[7][7];
    String fin[][] = new String[7][7];
    Random r = new Random();
    //   Random r2= new Random();
    String tech[][]=new String[7][7];
    int track[] = new int[7];
    String temp[][] = new String[5][5];
    String use[][] = new String[5][5];
    int backup[][]=new int[5][5];
    String prac=null;


    public void accumulate(String batch) {
    System.out.println("entering accumulate");
    int a, c;
    for (a = 0; a < 5; a++) {
    for (c = 0; c < 5; c++) {
    dat[a][c] = "free";
    checksum[a][c]=3;
    }
    }

    try {
    Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
    Connection conn3 = DriverManager.getConnection("jdbc:odbc:prac", "", "");
    Statement stat = conn3.createStatement();
    //System.out.println("select * from " + batch + "_t;");
    c = 0;
    ResultSet rs1 = stat.executeQuery("select * from " + batch + "_t;");
    while (rs1.next()) {
    //                System.out.println("checkpoint 1");
    for (a = 0; a < 4; a++) {
    dat[c][a] = rs1.getString(a + 1).trim();
    //System.out.print(dat[c][a] + "   ");
    }
    c++;
    System.out.println();
    }
    rs1.close();






    Statement state = conn3.createStatement();
    System.out.println("select * from " + batch + "_t;");
    c = 0;
    ResultSet rs3 = stat.executeQuery("select * from " + batch + "_track;");
    System.out.println("checkpoint 1");
    while (rs3.next()) {


    for (a = 0; a < 4; a++) {
    checksum[c][a] = rs3.getInt(a + 1);
    System.out.print(checksum[c][a] + "   ");
    }
    System.out.println();
    c++;

    }

    rs3.close();


    //            Statement stet = conn3.createStatement();
    //            Statement stest = conn3.createStatement();
    //            System.out.println("drop table " + fin[rand1][0] +"_track_1;");
    //            stet.execute("drop table " + fin[rand1][0] +"_track_1;");
    //            stet.close();
    //            System.out.println("create table " + fin[rand1][0] + "_track_1(1 number,2 number, 3 number,4 number);");
    //            stest.execute("create table " + fin[rand1][0] + "_track_1(1 number,2 number, 3 number,4 number);");
    //            stest.close();
    //            PreparedStatement ps1;
    //            System.out.println("insert into " + fin[rand1][0] + "_track_1  values(?,?,?,?);");
    //            
    //            System.out.println("checkpoint recovery"); 
    //          for(u = 0;u<5;u++) 
    //            {
    //                
    //                ps1 = conn3.prepareStatement("insert into " + fin[rand1][0] + "_track_1  values(?,?,?,?);");
    //                
    //                for (j = 0; j < 4; j++) {
    //                   //System.out.println(u + "    " + j + "   " );
    //                      ps1.setInt(j + 1,checksum[u][j] );
    //                    //System.out.print("free");
    //                    }
    //                System.out.println();
    //                
    //                int r=ps1.executeUpdate();
    //            
    //            } 




    //ps1.close();
    conn3.close();
    System.out.println("sending back accumulate");

    } catch (Exception e) {
    System.out.println(e);
    }
    }

    public int method1()
    {
    System.out.println(" entering method1 function ");
    int j,sum=0;
    int tick=0 ;
    int rate=0 ; 
    int o=0;
    i = 0;
    for (int z = 0; z < max; z++) {
    track[z] = 3;    // no of batches
    System.out.println(track[z]);
    sum+=track[z];
    }

    y=-1;
    //System.out.println(y);
    //rand = (y)%max;
    //rand1=rand;

    while(sum!=0)
    {
    y=(y+1)%max;



    accumulate(fin[y][0]);
    tick=0;

    for (int c = 0; c < 5; c++){ 
    for (int a = 0; a < 4; a++) {
    tick = tick + checksum[c][a];
     }
    }
    for ( int c = 0; c < 5; c++){ 
    for (int a = 0; a < 4; a++) {
     System.out.print(temp[c][a] );
     }
    System.out.println();    
    }

    System.out.println(tick);
    if(tick>=55)
    {
    o = phase1(fin[y][0]);

    if (o==1){ System.out.println("Sucess");count=0;}
    else
    System.out.println("failure");
    if (o==-1)
    {   mainpage.dead++;
        new refresh(indo1); 

    }


    }
    else if(tick<55 && tick>=52)

    {
    o = phase2(fin[y][0]);

    if (o==1) {System.out.println("Sucess");count=0;}
    else
    System.out.println("failure");
    if (o==-1)
    {   mainpage.dead++;
        new refresh(indo1); 

    }

    track[y]=0;



    }

    else
    {
    o = phase3(fin[y][0]);
    if (o==1)
    {System.out.println("Sucess");count=0;}
    else
    System.out.println("failure");

    if (o==-1)
    {   mainpage.dead++;
        new refresh(indo1); 

    }
    }

    sum=0;
    for (int z = 0; z < max; z++)
    {
    sum+=track[z];

    }
    if(o==-1)
        break;
    }


    return(o);
    }



    int phase3(String cla)
    {
    System.out.println("phase 3");
    int m=0,n=3,flag=0,suc=0,tick,flag4=0;
    int kep=track[y]; 
    System.out.println(kep +"  "  );
    int sum=0;
    count=0;
    n=3;
    do
    {
       count++;
       m=0;
    if(count>20)
    {
    System.out.println();
    System.out.println();
    System.out.println("deadlock recovery");
    System.out.println();
    System.out.println();    


    return(-1);

    }

       while (m< 5 && kep>0)
       {
       System.out.println( m + "    " + n ); 
           tick=0;
        for (int c = 0; c < 5; c++){ 
        for (int a = 0; a < 4; a++) {
        tick = tick + checksum[c][a];
       }
      }
    //System.out.println("tick : " + tick); 

    if (tick==49 ||tick==46 ||tick==43 || tick==40)
    {
    int s=3;
    int q=0;

    do{ 
    count++;
    if(count>20)
    {
    System.out.println();
    System.out.println();
    System.out.println("deadlock recovery");
    System.out.println();
    System.out.println();    


    return(-1);

    }
    q=0;
    System.out.println("loop 1");   
    while(q<5 && kep>0) 
    {
        System.out.println("loop 1.1");
        if (track[y]!=0 && checksum[q][s]<3 && checksum[q][s]==1 && temp[q][s]=="free"){
        temp[q][s] = cla /*+ track[rand] */;
        System.out.println("Checkpoint 2= " + fin[y][0] + " at "+ q + s );
        kep--;
        checksum[q][s]--;
        count=0;  
        track[y]--;
        suc=1;
    }
     q++;
    } 
     s--;
     if(s<0){s=3;}
    }while(kep>0 && s>=0);
    } 

    else if(tick<49 && tick>46 )
    {
    System.out.println("loop last ");
        if(checksum[m][n]<3 && checksum[m][n]==1 && temp[m][n]=="free" ) 
    {
        System.out.println(" detected location "+ m +"  " + n);
        temp[m][n] = fin[y][0] /*+ track[rand] */;
        System.out.println("Checkpoint 2= " + fin[y][0] );
        //System.out.println( checksum[m][n] +  "  " + kep +"  "  );
        checksum[m][n]--;
        //System.out.println( checksum[m][n] +  "  " + kep +"  "  );
        kep--;
        flag=0;
        count=0;
        track[y]--;
        suc=1;
    }

    }
    else if(checksum[m][n]<3 && checksum[m][n]==2 && temp[m][n]=="free" ) 
    {
        System.out.println(" detected location "+ m +"  " + n);
        temp[m][n] = fin[y][0] /*+ track[rand] */;
        System.out.println("Checkpoint 2= " + fin[y][0] );
        //System.out.println( checksum[m][n] +  "  " + kep +"  "  );
        checksum[m][n]--;
        //System.out.println( checksum[m][n] +  "  " + kep +"  "  );
        kep--;
        flag=0;
        count=0;
        track[y]--;
        suc=1;
     }


       m++;  

      } 

       n--;
       if(n<0)n=3;
    //if(n==0 && kep>0) {n=3; System.out.println("n=0");}         
    }while(kep>0);

    for (int i = 0; i < 5; i++) {
    for (int j = 0; j < 4; j++) {
    System.out.print(temp[i][j] + "  ");
    }
    System.out.println();
    }

    checker(y);


    return(suc);
    }










    int phase2(String cla)
    {
    System.out.println("phase 2");
    int m=0,n=3,flag=0,suc=0,tick;
    int kep=track[y]; 
    System.out.println(kep +"  "  );
    int sum=0;

    do
    {
       count++;
    if(count>20)
    {
    System.out.println();
    System.out.println();
    System.out.println("deadlock recovery");
    System.out.println();
    System.out.println();    


    return(-1);

    }
       /*  if(count>8)
    {
    System.out.println();
    System.out.println();
    System.out.println("deadlock recovery");
    System.out.println();
    System.out.println();    

    for (l = 0; l < max; l++) {
    track[l] = 3;    // no of batches
    System.out.print(track[l] + "  ");
    }
    try {
    Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
    Connection conn3 = DriverManager.getConnection("jdbc:odbc:prac", "", "");
    Statement state = conn3.createStatement();
    for(int f=0;f<max;f++)

    {
    System.out.println("select * from " + fin[f][0] + "_track_1;");
    int c = 0;
    ResultSet rs3 = state.executeQuery("select * from " + fin[f][0] + "_track_1;");
    System.out.println("checkpoint 1");
    while (rs3.next()) {


    for (int a = 0; a < 4; a++) {
    checksum[c][a]=rs3.getInt(a + 1);
    System.out.print(checksum[c][a] + "   ");
    }
    System.out.println();
    c++;

    }
    rs3.close();
    conn3.close();
    checker(f);

    }

    } catch (Exception e) {
    System.out.println(e);
    }        


    return(0); 
    }*/
       m=0;
       while (m< 5 && kep>0)
       {
        tick=0;
        for (int c = 0; c < 5; c++){ 
        for (int a = 0; a < 4; a++) {
        tick = tick + checksum[c][a];
         }
         }

    if (tick==52)
    {
    int s=3;
    int q=0;
    System.out.println("loop 1");
    do{ 
    count++;
    if(count>20)
    {
    System.out.println();
    System.out.println();
    System.out.println("deadlock recovery");
    System.out.println();
    System.out.println();    


    return(-1);

    }
    /* if(count>8)
    {
    System.out.println();
    System.out.println();
    System.out.println("deadlock recovery");
    System.out.println();
    System.out.println();    

    for (l = 0; l < max; l++) {
    track[l] = 3;    // no of batches
    System.out.print(track[l] + "  ");
    }
    try {
    Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
    Connection conn3 = DriverManager.getConnection("jdbc:odbc:prac", "", "");
    Statement state = conn3.createStatement();
    for(int f=0;f<max;f++)

    {
    System.out.println("select * from " + fin[f][0] + "_track_1;");
    int c = 0;
    ResultSet rs3 = state.executeQuery("select * from " + fin[f][0] + "_track_1;");
    System.out.println("checkpoint 1");
    while (rs3.next()) {


    for (int a = 0; a < 4; a++) {
    checksum[c][a]=rs3.getInt(a + 1);
    System.out.print(checksum[c][a] + "   ");
    }
    System.out.println();
    c++;

    }
    rs3.close();
    conn3.close();
    checker(f);

    }

    } catch (Exception e) {
    System.out.println(e);
    }        


    return(0); 
    }*/
       q=0;
       while(q<5 && kep>0) 
    {
        if (track[y]!=0 && checksum[q][s]==1 && temp[q][s]=="free" ){
        temp[q][s] = cla /*+ track[rand] */;
        System.out.println("Checkpoint 2= " + fin[y][0] + " at "+ q + s );
        kep--;
        checksum[q][s]--;
        count=0;  
        suc=1;
            }
     q++;
    } 
     s--; 
    }while(s>0 && kep>0);
    } 



        else if(checksum[m][n]<3 && checksum[m][n]>1 && temp[m][n]=="free" ) 
    {
           System.out.println(" detected location "+ m +"  " + n);
           flag++;

      if(flag==2)
     {
        System.out.println("inside flag ");
          temp[m][n] = fin[y][0] /*+ track[rand] */;
        System.out.println("Checkpoint 2= " + fin[y][0] );
        //System.out.println( checksum[m][n] +  "  " + kep +"  "  );
        checksum[m][n]--;
        //System.out.println( checksum[m][n] +  "  " + kep +"  "  );
        kep--;
        flag=0;
        count=0;
     }
     }


       m++;
       } 

       n--;
    if(n<0) n=3;         
    }while(kep>0);
    for (int i = 0; i < 5; i++) {
    for (int j = 0; j < 4; j++) {
    System.out.print(temp[i][j] + "  ");
    }
    System.out.println();
    }

    checker(y);
    if(kep==0) suc=1;

    return(suc);
    }


    int phase1(String cla) 
    {
    int s,q,tick,flag4=0;
    int suc=0;
    tick=0;

    for (int c = 0; c < 5; c++){ 
    for (int a = 0; a < 4; a++) {
    tick = tick + checksum[c][a];
    }
    }
    if(tick>55){
    do{
    flag4=0;      
    System.out.println("ram place");
    rand1 =r.nextInt(5);
    rand = r.nextInt(4);
    System.out.println("randon no1: " + rand);
    System.out.println("randon no2: " + rand1);        

    //System.out.println(temp[rand1][rand]);
    for(int d=0;d<4;d++)
    {
    System.out.println(temp[rand1][d]);
    System.out.println(dat[rand1][rand]);
    System.out.println(flag4);
    if(temp[rand1][d]==fin[y][0] || checksum[rand1][d]!=3 )
    {flag4=1;}
    }
    System.out.println(flag4);
    }while(flag4==1 || temp[rand1][rand]!="free" || checksum[rand1][rand]!=3);

    }
    System.out.println("check phase");

    count++;
    if(count>20)
    {
    System.out.println();
    System.out.println();
    System.out.println("deadlock recovery");
    System.out.println();
    System.out.println();    


    return(-1);

    }    
    /*
    for (l = 0; l < max; l++) {
    track[l] = 3;    // no of batches
    System.out.print(track[l] + "  ");
    }
    try {
    Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
    Connection conn3 = DriverManager.getConnection("jdbc:odbc:prac", "", "");
    Statement state = conn3.createStatement();
    for(int f=0;f<max;f++)

    {
    System.out.println("select * from " + fin[f][0] + "_track_1;");
    int c = 0;
    ResultSet rs3 = state.executeQuery("select * from " + fin[f][0] + "_track_1;");
    System.out.println("checkpoint 1");
    while (rs3.next()) {


    for (int a = 0; a < 4; a++) {
    checksum[c][a]=rs3.getInt(a + 1);
    System.out.print(checksum[c][a] + "   ");
    }
    System.out.println();
    c++;

    }
    rs3.close();
    conn3.close();
    checker(f);

    }

    } catch (Exception e) {
    System.out.println(e);
    }        


    return(0); 
    }*/



    do
    {
    //System.out.println(temp[q][s-1] + "    "+ temp[q][s] +"    "+ temp[q][s+1] + " at " + q  + s);
    tick=0;

    for (int c = 0; c < 5; c++){ 
    for (int a = 0; a < 4; a++) {
    tick = tick + checksum[c][a];
    }
    }



    System.out.println("loop");     

    System.out.println(dat[rand1][rand]);
    System.out.println(checksum[rand1][rand]);
    //System.out.println(checksum[q][s-1]);
    //System.out.println(checksum[q][s+1]);
    System.out.println(temp[rand1][rand]);
    System.out.println(tick);

    if ( tick==55  )
    {
    int s1=3;
    int q1=0;
    count++;
    if(count>10)
    {
    System.out.println();
    System.out.println();
    System.out.println("deadlock recovery");
    System.out.println();
    System.out.println();    


    return(-1);

    }

    System.out.println("loop 1");
    do{ 
       q1=0;
       while(q1<5 && track[y]>0) 
      {
        System.out.println(track[y] + "   " +checksum[q1][s1] + "   " + temp[q1][s1] );

        if (track[y]!=0 && checksum[q1][s1]<3 && temp[q1][s1]=="free" ){
        temp[q1][s1] = cla /*+ track[rand] */;
        System.out.println("Checkpoint 2= " + fin[rand1][0] + " at "+ q1 + s1 );
        track[y]--;
        checksum[q1][s1]--;
        count=0;  
        suc=1;
            }
    q1++;
    } 
    s1--; 
    }while(s1>0 && track[y]>0);
    }




    else if (dat[rand1][rand].equals("free") && track[y]!=0 && checksum[rand1][rand]==3 && temp[rand1][rand]=="free" && tick>55)
    {
        System.out.println("loop 2");       
        temp[rand1][rand] = cla /*+ track[rand] */;
        //System.out.println("Checkpoint 2= " + fin[rand1][0] + " at "+ q + s );
        track[y]--;
        checksum[rand1][rand]--;
        count=0;  
        suc=1;
    }



    System.out.println("suc=" + suc);
    }while(suc==0);

    //System.out.println(s);


    checker(y);
    for (int a = 0; a < 5; a++) {
    for (int c = 0; c < 4; c++) {
    System.out.print(checksum[a][c]);
    }
    System.out.println();
    }
    return (suc);
    } 


    public void checker(int rand1)
    {
    try
    {
    Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
    Connection conn2 = DriverManager.getConnection("jdbc:odbc:prac", "", "");
    Statement stet = conn2.createStatement();
    Statement stest = conn2.createStatement();

    System.out.println("drop table " + fin[rand1][0] +"_track;");
    stet.execute("drop table " + fin[rand1][0] +"_track;");
    stet.close();
    System.out.println("create table " + fin[rand1][0] + "_track(1 number,2 number, 3 number,4 number);");
    stest.execute("create table " + fin[rand1][0] + "_track(1 number,2 number, 3 number,4 number);");

    PreparedStatement ps1;
    System.out.println("insert into " + fin[rand1][0] + "_track  values(?,?,?,?);");

    System.out.println("checkpoint checker"); 
    for(u = 0;u<5;u++) 
    {

    ps1 = conn2.prepareStatement("insert into " + fin[rand1][0] + "_track  values(?,?,?,?);");

    for (j = 0; j < 4; j++) {
    //System.out.println(u + "    " + j + "   " );
      ps1.setInt(j + 1, checksum[u][j]);
    //System.out.print("free");
    }
    System.out.println();

    int r=ps1.executeUpdate();
    System.out.println(r);


    }

    conn2.close();

    }
    catch(Exception e){System.out.println(e);}



    }




    public void stuff(String clas) {
    System.out.println("recived " + clas);
    int a, c;


    System.out.println ();
    System.out.println ();
    System.out.println ();
    System.out.println ();
    for (a = 0; a < 5; a++) {
    for (c = 0; c < 4; c++) {
    System.out.print(use[a][c] + "   ");
    }
    System.out.println ();
    }
    System.out.println ();
    System.out.println ();
    System.out.println ();

    try {
    Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
    Connection conn2 = DriverManager.getConnection("jdbc:odbc:prac", "", "");
    Statement stet = conn2.createStatement();
    Statement stest = conn2.createStatement();
    Statement stat = conn2.createStatement();
    ResultSet rs1 = stat.executeQuery("select * from " + clas +"_t;");
    System.out.println("select * from " + clas +"_t;");

    a = 0;
    c = 0;
    while (rs1.next()) {
    for (a = 0; a <4; a++) {
    tech[c][a] = rs1.getString(a + 1);
    }
    c++;
    }
    stat.close();
    System.out.println("drop table " + clas +"_t;");
    stet.execute("drop table " + clas +"_t;");
    stet.close();
    System.out.println("create table " + clas + "_t(1 varchar(20),2 varchar(15), 3 varchar(15),4 varchar(15));");
    stest.execute("create table " + clas + "_t(1 varchar(200),2 varchar(200), 3 varchar(200),4 varchar(200));");



    PreparedStatement ps1;
    System.out.println("insert into " + clas + "_t  values(?,?,?,?);");


    for(u = 0;u<5;u++) {
    System.out.println("checkpoint stuff"); 
    ps1 = conn2.prepareStatement("insert into " + clas + "_t  values(?,?,?,?);");

    for (j = 0; j < 4; j++) {
    System.out.println(u + "    " + j + "   " );
    //if (use[u][j] != "free") {
    //    {
    //        if(tech[u][j]!=null && tech[u][j]!="free")
    //        use[u][j]= tech[u][j] + " , " + use[u][j];
    //        else if(tech[u][j]=="free")
    //           use[u][j]=use[u][j]; 

            ps1.setString(j + 1, use[u][j]);
    //    System.out.print(use[u][j]+ "  " );
    //    }
    //    } else {
    //
    //   ps1.setString(j + 1, "free");
    //    System.out.print("free");
    //}
    //System.out.println();
    }
    int r=ps1.executeUpdate();
    System.out.println(r);

    System.out.println();
    }

    conn2.close();
    } catch (Exception e) {
    System.out.println(e);
    }

    }

    public void organize(String str) {
    try {
    String pracs;
    pracs = str + "_t";
    System.out.println(pracs);
    Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
    Connection conn1 = DriverManager.getConnection("jdbc:odbc:prac", "", "");
    Statement stat = conn1.createStatement();
    ResultSet rs1 = stat.executeQuery("select * from " + str + ";");
    System.out.println("select * from " + str + ";");

    int a = 0, b = 0;
    while (rs1.next()) {
    for (a = 0; a < 5; a++) {
    fin[b][a] = rs1.getString(a + 1);
    System.out.print(fin[b][a] + "   ");
    }
    b++;
    System.out.println();
    }
    max = b;
    System.out.println("Checkpoint 1, no of records :" + max);
    stat.close();

    for (i = 0; i < 5; i++) {
    for (j = 0; j < 5; j++) {
    temp[i][j] = "free";
    System.out.print(temp[i][j]);
    }
    System.out.println();
    }


    //sum = track[0];




    int qc=method1();

    if(qc!=-1)
    {
    System.out.println(i + "   " + j);

    PreparedStatement ps = conn1.prepareStatement("insert into " + str + "_t  values(?,?,?,?);");
    for (i = 0; i < 5; i++) {
    for (j = 0; j < 4; j++) {
    ps.setString(j + 1, temp[i][j]);
    System.out.print(temp[i][j] + "   ");    
    }
    int r = ps.executeUpdate();
    System.out.println();
    }

    ps.close();

    conn1.close();

    k = 0;
    while (k < max) {


    for (i = 0; i < 5; i++) {
    for (j = 0; j < 4; j++) {
        use[i][j] = "free";
    }
    }

    accumulate(fin[k][0]);


    for (i = 0; i < 5; i++) {
    for (j = 0; j < 4; j++) {
        if (temp[i][j].equals(fin[k][0]) && checksum[i][j]!=3) 
            use[i][j] =dat[i][j].trim() +"," + str ;

        else if (temp[i][j].equals(fin[k][0]) && checksum[i][j]==3)
            use[i][j] =prac ;

        else if (temp[i][j]!=fin[k][0] && checksum[i][j]==3)
            use[i][j] = "free";

        else if (temp[i][j]!=fin[k][0] && checksum[i][j]!=3)
            use[i][j] = dat[i][j];

    }

    }
    System.out.println("trasferring data to stuff function");
    stuff(fin[k][0]);

    k++;
    }

    }
    } catch (Exception e) {
    System.out.println(e);
    }



    }

    public schedule1(int indo) {

    indo1=indo;
    if (indo==1)
        prac="Mech_Lab";
    else if (indo==2)
        prac="Physics_Lab";
    else if (indo==3)
        prac="EL_Lab_1";
    else if (indo==4)
        prac="Chemistry_Lab";
    else if (indo==5)
        prac="CE_Lab_1";
    //else if (indo==6)
    //    prac="Mech_Lab";

    try {
    System.out.println();
    System.out.println();

    System.out.println("the timetable for " + prac);
    System.out.println();
    System.out.println();

    organize(prac);




    } catch (Exception e) {
    }

     
    }
    
    
    
    }   

