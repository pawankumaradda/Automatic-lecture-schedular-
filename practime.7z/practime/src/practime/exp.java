/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package practime;
import practime.app.*;
import java.sql.*;
import java.util.*;
/**
 *
 * @author Pawan Kumar
 */
public class exp {
   int dead=0; 
   int checksum[][]=new int[5][5];
   int a[][]=new int[7][7]; 
   float g[]=new float[7]; 
   int g1[]=new int[7]; 
   int i=0,j=0,k,l,m,n=0,flag=5,v;
   int count=0,frg=0;
   int time[][]=new int[7][8];
   String b[][]=new String[7][8];
   String fin[][]=new String[7][8];
   Random r=new Random();
   String tech[]=new String[7];
   int track[]= new int[5];
   String temp[][]= new String[7][8];
   Statement s1,s2;
   
   private void populate(int k) 
   { int c,a;
   
       for(c=0;c<7;c++)
     {
       for(a=0;a<7;a++)
         {
          temp[c][a]="free";      
         //System.out.print(temp[c][a]); 
       }
     System.out.println("   ");
     }
       try
    {
    int f=0;
    Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
    Connection conn1=DriverManager.getConnection("jdbc:odbc:trial","","");
    Statement stat=conn1.createStatement();
    System.out.println("obtaining prev timetable for " + b[k][0]);
    ResultSet rs1=stat.executeQuery("select * from "+ b[k][0] + ";");
    System.out.println("select * from "+ b[k][0] + ";");
    
    c=0;
    a=0;
    while(rs1.next())
     {   
//        System.out.println("checkpoint 1");
        for(a=0;a<5;a++)
        {
                temp[c][a]=rs1.getString(a+1);
               
        }
     c++;
        
      
      }    
    
    System.out.println("populating finished....");
    stat.close();
    conn1.close(); 
   
     }
   catch(Exception e){ System.out.println(e.toString());}
    
   }
   
   
   
   
   public exp(String yr)
    
   {
       {
       int a, c;
    for (a = 0; a < 5; a++) {
    for (c = 0; c < 5; c++) {
    checksum[a][c]=3;
    }
    }
    
    
    for (a = 0; a < 7; a++) {
    for (c = 0; c < 8; c++) {
    time[a][c]=-1;
    }
    }
try {
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
Connection conn = DriverManager.getConnection("jdbc:odbc:prac", "", "");

Statement state = conn.createStatement();
System.out.println("select * from " + yr + "_track;");
c = 0;
ResultSet rs3 = state.executeQuery("select * from " + yr + "_track;");
System.out.println("checkpoint 1");
while (rs3.next()) {


for (a = 0; a < 4; a++) {
checksum[c][a] = rs3.getInt(a + 1);
System.out.print(checksum[c][a] + "   ");
}
System.out.println();
c++;

}
rs3.close();
conn.close();

for (a = 0; a < 5; a++) {
    for (c = 0; c < 4; c++) {
    if(checksum[a][c]==0)
    {
    int s=c*2;
    time[a][s]=-2;
    time[a][s+1]=-2;
    
    
    }
    
    }
    }

for (a = 0; a < 5; a++) {
    for (c = 0; c < 8; c++) {
    System.out.print(time[a][c]);
    }
System.out.println();    
}



}    
catch(Exception e){System.out.println(e.toString());}    
    
    
    }
         
    
   try
    
 {
    Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
    Connection conn=DriverManager.getConnection("jdbc:odbc:trial","","");
    Statement stat=conn.createStatement();
    
    ResultSet rs=stat.executeQuery("Select * from allocation where Year = '" + yr + "' ;"); 
    //System.out.println("Select * from allocation where Year = '" + yr + "' ;");
    
    while(rs.next()&& i<5)
    {   while(j<5)
        
        {
                b[i][j]=rs.getString(j+1);
                j++;
        }
            
        j=0;
        i++;
        
       
     }     
     
    
//    for(i=0;i<5;i++)
//     {
//        k=(r.nextInt(9));
//         for(j=0;j<5;j++)
//         {
//             
//             System.out.print(" "+b[i][j]);
//         
//         }
//     System.out.println("\n "+k );
//     }
        
    
    for(i=0;i<5;i++)
     {
             g[i]=Integer.parseInt(b[i][1])/Integer.parseInt(b[i][2]);
             System.out.println(g[i]);
             
             if(g[i]>=1)
             {
                 g1[i]=5;
                 
             }
             else 
             {
                 g1[i]=6;
                 flag=6;
             }
    }
    
//    for(i=0;i<7;i++)
//     {
//       for(j=0;j<7;j++)
//         {
//          time[i][j]=-1;      
//          System.out.print(time[i][j]);
//       }
//     System.out.println("  ");
//     }
    
    
    for(j=0;j<5;j++)
    {       
     track[j]=0;
        System.out.println(g1[j]);
    }
    
    
    m=0;
    n=0;
    
    while(g1[0]!=0 || g1[1]!=0 || g1[2]!=0 || g1[3]!=0 || g1[4]!=0  )
    {   
        j=0;
        while(time[n][j]!=-2 )
        {
               j++; 
        }   
       
     do
    {       
      if(time[n][j]==-2)
          j--;
       
      
      if(j<0 ) {j=2;frg=1;}
      
      if(count==10)
       {
          System.out.println();  
          System.out.println();
          System.out.println("preparing deadlock recovery");
          count=0;
          
          for(i=0;i<=j;i++)
       {
       if(time[n][i]!=-2)
           time[n][i]=-1;
       }
       j=0;
      for(i=0;i<5;i++){track[i]=0;} 
      for(i=0;i<5;i++)
      {
          if(i!=k)
          g1[i]++;
      
      
      }
      for(i=0;i<5;i++){System.out.print(g1[i]+"   ");}
      }    
      
       do
       {
       k=r.nextInt(5);
       System.out.println("k= " + k);
       }while(track[k]!=0 || g1[k]==0 );
       
      System.out.println();
       System.out.println();
       System.out.println("initializing populate for " + b[k][0] + " ie " + k + " for location " + n +"  "+ j);
       
       populate(k);    
       
       System.out.println("checkpoint 3 " + j);
       System.out.println();
       System.out.println(time[n][j]);
       System.out.println(temp[n][j]);
       
       count++;
       if(g1[k]>0 && time[n][j]==-1 && temp[n][j].equals("free"))
       {
        
        time[n][j]=k ;
        g1[k]--;
        System.out.println("inserted at " + n +","+ j + " " + time[n][j]); 
        track[k]=1;       
        if(frg==0)
        j--;
        else if(frg==1)
            j++;
        
        
        if(j<0)
        {
        j=0;
        while(time[n][j]!=-2)
            j++;
        
        j=j+2;
        frg=1;
        }
        
        //System.out.println("checkpoint 4  " + j);
        count=0;
       
       for (int a = 0; a < 5; a++) {
    for (int c = 0; c < 8; c++) {
    System.out.print(" " + time[a][c]+ " ");
    }
System.out.println();    
}
       }
       
       /*else if(temp[n][j]!="free")
       {
          
        j++; 
        System.out.println("checkpoint 5" + j);
       }*/
       
        if(track[0]!=0 && track[1]!=0 && track[2]!=0 && track[3]!=0 && track[4]!=0 )
        break;
     System.out.println("checkpoint 4 " + j); 
     }while(time[n][j]<=-1 && j<8 && j>=0);
      n=(n+1)%5;
       frg=0;
      System.out.println("hellooooooooo " + n);
      for(i=0;i<5;i++){track[i]=0;}
      for(i=0;i<5;i++){System.out.print(g1[i]+"   ");}
      System.out.println();
    }
   
   
    System.out.println();
    System.out.println();
    System.out.println();
    
    
    for(i=0;i<5;i++)
     {
       for(j=0;j<8;j++)
         {
          System.out.print(time[i][j]+ "   ");      
                  
       }
     System.out.println();
     }
    
    for(j=0;j<5;j++)
    {
        tech[j]=b[j][1];
    }
    
    m=0;
    
    for(i=0;i<5;i++)
     {
       for(j=0;j<8;j++)
         {
        m=time[i][j];       
        
        if(m>-1 )
        {System.out.print("  " + b[m][0]+"   ");          
        fin[i][j]=b[m][0];
        }
        else if(m==-2)
        {System.out.print("  pracs   ");          
        fin[i][j]="pracs";
        }

        else
        {
        System.out.print("  free   ");   
        fin[i][j]="free";
        }
       }
        System.out.println();
     }
       Statement stet1=conn.createStatement();
    Statement stest1=conn.createStatement();
       //System.out.println("drop table " + yr +";");
       //s1.execute("drop table " + yr +";");
       //System.out.println("check");
       //s1.close();
       //s2.execute("create table " + yr + "(1 varchar(9),2 varchar(9), 3 varchar(9),4 varchar(9),5 varchar(9),6 varchar(9),7 varchar(9));");  
       //System.out.print("up");
       stet1.execute("drop table " + yr +";");
       //System.out.println("drop table " + b [m][0] +";");
       stet1.close();
       stest1.execute("create table " + yr + "(1 varchar(9),2 varchar(9), 3 varchar(9),4 varchar(9),5 varchar(9),6 varchar(9),7 varchar(9),8 varchar(9));");
       stest1.close();
       PreparedStatement ps= conn.prepareStatement("insert into " + yr +"  values(?,?,?,?,?,?,?,?);");
       
       for(i=0;i<5;i++)
     {
       
       for(j=0;j<8;j++)
       {
            ps.setString(j+1, fin[i][j]);
//            System.out.print(fin[i][j] +"   ");
       }
   int x= ps.executeUpdate();   
   System.out.println(x);
   
   }
   //ps.close();
   
   
   
   
   
   
   for(m=0;m<5;m++)
   {
    Statement stet=conn.createStatement();
    Statement stest=conn.createStatement();
    ResultSet rs2=stet.executeQuery("select * from "+ b[m][0] + ";");
    int c=0,a=0;
    System.out.println(b[m][0]);
    while(rs2.next())
    {   
        for(a=0;a<5;a++)
        {
            System.out.println();    
            temp[c][a]=rs2.getString(a+1);
               
        }
       c++;
    
     }    
    System.out.println("check1");   
    rs2.close();
       stet.execute("drop table " + b [m][0] +";");
       //System.out.println("drop table " + b [m][0] +";");
       stet.close();
       stest.execute("create table " + b[m][0] + "(1 varchar(9),2 varchar(9), 3 varchar(9),4 varchar(9),5 varchar(9),6 varchar(9),7 varchar(9),8 varchar(9));");  
       //System.out.println("create table " + b[m][0] + "(1 varchar(9),2 varchar(9), 3 varchar(9),4 varchar(9),5 varchar(9),6 varchar(9),7 varchar(9));");
       String str="insert into "+ b[m][0] + " values(?,?,?,?,?,?,?,?);";
       stest.close();
       //System.out.println(str);
       PreparedStatement ps1= conn.prepareStatement(str); 
       for(i=0;i<5;i++)
        {
       
            for(j=0;j<8;j++)
            {
            if(time[i][j]==m)
               fin[i][j]=yr;
            else if(temp[i][j]!="free")
               fin[i][j]=temp[i][j];
            else
                fin[i][j]="free";
                System.out.print(fin[i][j]+ "  ");
                ps1.setString(j+1, fin[i][j]);
             }
       int x= ps1.executeUpdate();   
//     System.out.println(x); 
      // System.out.println();
       }
       ps1.close();
   
   }
       
     conn.close();  
       
       }       
catch(Exception e)
{System.out.println(e.toString());}
    System.out.println();
    System.out.println();
    System.out.println();
    System.out.println();
    System.out.println("The number of Deadlocks occured during execution of the program: "+ dead);
   }

    
}