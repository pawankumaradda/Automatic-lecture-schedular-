/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package practime;
import java.sql.*;
//import java.util.*;
/**
 *
 * @author Pawan Kumar
 */
public class refresh {

    
public refresh(int indo){
    System.out.println("refresh");

try {
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
Connection conn2 = DriverManager.getConnection("jdbc:odbc:prac", "", "");
Statement stet = conn2.createStatement();
Statement stest = conn2.createStatement();
PreparedStatement ps1=null;
System.out.println("drop table FEit_t;");
stet.execute("drop table FEit_t;");
stet.close();
System.out.println("create table FEit_t(1 varchar(200),2 varchar(200), 3 varchar(200),4 varchar(200));");
stest.execute("create table FEit_t(1 varchar(200),2 varchar(200), 3 varchar(200),4 varchar(200));");    
stest.close();

stet = conn2.createStatement();
stest = conn2.createStatement();
System.out.println("drop table FEce_t;");
stet.execute("drop table FEce_t;");
stet.close();
System.out.println("create table FEce_t(1 varchar(200),2 varchar(200), 3 varchar(200),4 varchar(200));");
stest.execute("create table FEce_t(1 varchar(200),2 varchar(200), 3 varchar(200),4 varchar(200));");    
stest.close();

stet = conn2.createStatement();
stest = conn2.createStatement();
System.out.println("drop table FEextc_t;");
stet.execute("drop table FEextc_t;");
stet.close();
System.out.println("create table FEextc_t(1 varchar(200),2 varchar(200), 3 varchar(200),4 varchar(200));");
stest.execute("create table FEextc_t(1 varchar(200),2 varchar(200), 3 varchar(200),4 varchar(200));");    
stest.close();


stet = conn2.createStatement();
stest = conn2.createStatement();
System.out.println("drop table FEit_track;");
stet.execute("drop table FEit_track;");
stet.close();
System.out.println("create table FEit_track(1 number,2 number, 3 number,4 number);");
stest.execute("create table FEit_track(1 number,2 number, 3 number,4 number);");
System.out.println("insert into FEit_track  values(?,?,?,?);");
for(int u = 0;u<5;u++) 
{

ps1 = conn2.prepareStatement("insert into FEit_track  values(?,?,?,?);");

for (int j = 0; j < 4; j++) {
//System.out.println(u + "    " + j + "   " );
  ps1.setInt(j + 1, 3);
//System.out.print("free");
}
System.out.println();

int r=ps1.executeUpdate();
System.out.println(r);
}


stet = conn2.createStatement();
stest = conn2.createStatement();
System.out.println("drop table FEce_track;");
stet.execute("drop table FEce_track;");
stet.close();
System.out.println("create table FEce_track(1 number,2 number, 3 number,4 number);");
stest.execute("create table FEce_track(1 number,2 number, 3 number,4 number);");
System.out.println("insert into FEce_track  values(?,?,?,?);");
for(int u = 0;u<5;u++) 
{

ps1 = conn2.prepareStatement("insert into FEce_track  values(?,?,?,?);");

for (int j = 0; j < 4; j++) {
//System.out.println(u + "    " + j + "   " );
  ps1.setInt(j + 1, 3);
//System.out.print("free");
}
System.out.println();

int r=ps1.executeUpdate();
System.out.println(r);


}


stet = conn2.createStatement();
stest = conn2.createStatement();
System.out.println("drop table FEextc_track;");
stet.execute("drop table FEextc_track;");
stet.close();
System.out.println("create table FEextc_track(1 number,2 number, 3 number,4 number);");
stest.execute("create table FEextc_track(1 number,2 number, 3 number,4 number);");
System.out.println("insert into FEextc_track  values(?,?,?,?);");
for(int u = 0;u<5;u++) 
{

ps1 = conn2.prepareStatement("insert into FEextc_track  values(?,?,?,?);");

for (int j = 0; j < 4; j++) {
//System.out.println(u + "    " + j + "   " );
  ps1.setInt(j + 1, 3);
//System.out.print("free");
}
System.out.println();

int r=ps1.executeUpdate();
System.out.println(r);


}

stet = conn2.createStatement();
stest = conn2.createStatement();
System.out.println("drop table Mech_Lab_t;");
stet.execute("drop table Mech_Lab_t;");
stet.close();
System.out.println("create table Mech_Lab_t(1 varchar(20),2 varchar(15), 3 varchar(15),4 varchar(15));");
stest.execute("create table Mech_Lab_t(1 varchar(20),2 varchar(20), 3 varchar(20),4 varchar(20));");    
stest.close();

stet = conn2.createStatement();
stest = conn2.createStatement();
System.out.println("drop table EL_Lab_1_t;");
stet.execute("drop table EL_Lab_1_t;");
stet.close();
System.out.println("create table EL_Lab_1_t(1 varchar(20),2 varchar(15), 3 varchar(15),4 varchar(15));");
stest.execute("create table EL_Lab_1_t(1 varchar(20),2 varchar(20), 3 varchar(20),4 varchar(20));");    
stest.close();

stet = conn2.createStatement();
stest = conn2.createStatement();
System.out.println("drop table CE_Lab_1_t;");
stet.execute("drop table CE_Lab_1_t;");
stet.close();
System.out.println("create table CE_Lab_1_t(1 varchar(20),2 varchar(15), 3 varchar(15),4 varchar(15));");
stest.execute("create table CE_Lab_1_t(1 varchar(20),2 varchar(20), 3 varchar(20),4 varchar(20));");    
stest.close();

stet = conn2.createStatement();
stest = conn2.createStatement();
System.out.println("drop table Physics_Lab_t;");
stet.execute("drop table Physics_Lab_t;");
stet.close();
System.out.println("create table Physics_Lab_t(1 varchar(20),2 varchar(15), 3 varchar(15),4 varchar(15));");
stest.execute("create table Physics_Lab_t(1 varchar(20),2 varchar(20), 3 varchar(20),4 varchar(20));");    
stest.close();

stet = conn2.createStatement();
stest = conn2.createStatement();
System.out.println("drop table Chemistry_Lab_t;");
stet.execute("drop table Chemistry_Lab_t;");
stet.close();
System.out.println("create table Chemistry_Lab_t(1 varchar(20),2 varchar(15), 3 varchar(15),4 varchar(15));");
stest.execute("create table Chemistry_Lab_t(1 varchar(20),2 varchar(20), 3 varchar(20),4 varchar(20));");    
stest.close();



ps1.close();

conn2.close();
}
catch(Exception e){System.out.println(e.toString());}

for(int i=1; i<=indo; i++ )
{
schedule1 s=new schedule1(i);
}
    
    











}
}