/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package practime;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 *
 * @author Pawan Kumar
 */
@RunWith(Suite.class)
@Suite.SuiteClasses({practime.indexTest.class,practime.mainpageTest.class,practime.schedule1Test.class,practime.appTest.class})
public class PractimeSuite {

}