/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package practime;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Pawan Kumar
 */
public class schedule1Test {

    public schedule1Test() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of accumulate method, of class schedule1.
     */
    @Test
    public void testAccumulate() {
        System.out.println("accumulate");
        String batch = "";
        schedule1 instance = null;
        instance.accumulate(batch);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of method1 method, of class schedule1.
     */
    @Test
    public void testMethod1() {
        System.out.println("method1");
        schedule1 instance = null;
        int expResult = 0;
        int result = instance.method1();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of phase3 method, of class schedule1.
     */
    @Test
    public void testPhase3() {
        System.out.println("phase3");
        String cla = "";
        schedule1 instance = null;
        int expResult = 0;
        int result = instance.phase3(cla);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of phase2 method, of class schedule1.
     */
    @Test
    public void testPhase2() {
        System.out.println("phase2");
        String cla = "";
        schedule1 instance = null;
        int expResult = 0;
        int result = instance.phase2(cla);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of phase1 method, of class schedule1.
     */
    @Test
    public void testPhase1() {
        System.out.println("phase1");
        String cla = "";
        schedule1 instance = null;
        int expResult = 0;
        int result = instance.phase1(cla);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of checker method, of class schedule1.
     */
    @Test
    public void testChecker() {
        System.out.println("checker");
        int rand1 = 0;
        schedule1 instance = null;
        instance.checker(rand1);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of stuff method, of class schedule1.
     */
    @Test
    public void testStuff() {
        System.out.println("stuff");
        String clas = "";
        schedule1 instance = null;
        instance.stuff(clas);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of organize method, of class schedule1.
     */
    @Test
    public void testOrganize() {
        System.out.println("organize");
        String str = "";
        schedule1 instance = null;
        instance.organize(str);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

}